export interface clickResponse
{
   
    score ?:number;
    submit():void;
}